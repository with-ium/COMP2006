#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "scheduler.h"

struct arg_struct {
    char *input;
    int cur;
    int prev;
    int *requests;
    int size;
    int cylinders;
};

pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond1 = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond2 = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond3 = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond4 = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond5 = PTHREAD_COND_INITIALIZER;
pthread_cond_t condb2 = PTHREAD_COND_INITIALIZER;

int work = 0;

void *FCFS_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = malloc(sizeof(int));
    pthread_mutex_lock(&lock1);

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = FCFS(args->cur, args->requests, args->size);
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    work = 1;
    pthread_cond_signal(&cond1);
    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void *SSTF_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = (int *)malloc(sizeof(int));
    pthread_mutex_lock(&lock1);
    while (work != 1) {
        pthread_cond_wait(&cond1, &lock1);
    }

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = SSTF(args->cur, args->requests, args->size);
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    work = 2;
    pthread_cond_signal(&cond2);
    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void *SCAN_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = (int *)malloc(sizeof(int));
    pthread_mutex_lock(&lock1);
    while (work != 2) {
        pthread_cond_wait(&cond2, &lock1);
    }

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = SCAN(args->cur, args->prev, args->requests, args->size, args->cylinders);
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    work = 3;
    pthread_cond_signal(&cond3);
    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void *CSCAN_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = (int *)malloc(sizeof(int));
    pthread_mutex_lock(&lock1);
    while (work != 3) {
        pthread_cond_wait(&cond3, &lock1);
    }

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = C_SCAN(args->cur, args->prev, args->requests, args->size, args->cylinders);
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    work = 4;
    pthread_cond_signal(&cond4);
    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void *LOOK_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = (int *)malloc(sizeof(int));
    pthread_mutex_lock(&lock1);
    while (work != 4) {
        pthread_cond_wait(&cond4, &lock1);
    }

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = LOOK(args->cur, args->prev, args->requests, args->size); 
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    work = 5;
    pthread_cond_signal(&cond5);
    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void *CLOOK_thread(void *arguments) {
    struct arg_struct *args = (struct arg_struct*)arguments;
    int *buf2 = (int *)malloc(sizeof(int));
    pthread_mutex_lock(&lock1);
    while (work != 5) {
        pthread_cond_wait(&cond5, &lock1);
    }

    /* Start critical section */
    if (strcmp(args->input, "QUIT") != 0) {
        *buf2 = C_LOOK(args->cur, args->prev, args->requests, args->size); 
        pthread_cond_signal(&condb2);
    } else {
        printf("Thread %lu has terminated.\n", (unsigned long)pthread_self());
    }
    /* End critical section */

    pthread_mutex_unlock(&lock1);
    return (void *)buf2;
}

void createThreads(char *input, int cur, int prev, int *requests, int size, int cylinders) {
    pthread_t tidA;
    pthread_t tidB;
    pthread_t tidC;
    pthread_t tidD;
    pthread_t tidE;
    pthread_t tidF;

    int *buffer2; 
    struct arg_struct buffer1;
    buffer1.input = input;
    buffer1.cur = cur;
    buffer1.prev = prev;
    buffer1.requests = requests;
    buffer1.size = size;
    buffer1.cylinders = cylinders;

    pthread_create(&tidA, NULL, FCFS_thread, &buffer1);
    pthread_create(&tidB, NULL, SSTF_thread, &buffer1);
    pthread_create(&tidC, NULL, SCAN_thread, &buffer1);
    pthread_create(&tidD, NULL, CSCAN_thread, &buffer1);
    pthread_create(&tidE, NULL, LOOK_thread, &buffer1);
    pthread_create(&tidF, NULL, CLOOK_thread, &buffer1);
    work = 0;

    if (strcmp(input, "QUIT") != 0) {
        pthread_join(tidA, (void**)&buffer2);
        printf("FCFS: %d.\n", *buffer2);

        pthread_join(tidB, (void*)&buffer2);
        printf("SSTF: %d.\n", *buffer2);

        pthread_join(tidC, (void*)&buffer2);
        printf("SCAN: %d.\n", *buffer2);

        pthread_join(tidD, (void*)&buffer2);
        printf("C-SCAN: %d.\n", *buffer2);

        pthread_join(tidE, (void*)&buffer2);
        printf("LOOK: %d.\n", *buffer2);

        pthread_join(tidF, (void*)&buffer2);
        printf("C-LOOK: %d.\n", *buffer2);
    }
    else {
        pthread_join(tidA, NULL);
        pthread_join(tidB, NULL);
        pthread_join(tidC, NULL);
        pthread_join(tidD, NULL);
        pthread_join(tidE, NULL);
        pthread_join(tidF, NULL);
    } 
}
