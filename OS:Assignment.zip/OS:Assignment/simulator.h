void createThreads();
void *FCFS_thread(void *arguments);
void *SSTF_thread(void *arguments);
void *SCAN_thread(void *arguments);
void *CSCAN_thread(void *arguments);
void *LOOK_thread(void *arguments);
void *CLOOK_thread(void *arguments);
void createThreads(char *input, int cur, int prev, int *requests, int size, int cylinders);
