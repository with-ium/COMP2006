int scheduler_compare(const int * num1, const int * num2);
int FCFS(int curPos, int* requests, int size);
int SSTF(int curPos, int* requests, int size);
int SCAN(int curPos, int prevPos, int* requests, int size, int diskSize);
int C_SCAN(int curPos, int prevPos, int* requests, int size, int diskSize);
int LOOK(int curPos, int prevPos, int* requests, int size);
int C_LOOK(int curPos, int prevPos, int* requests, int size);
