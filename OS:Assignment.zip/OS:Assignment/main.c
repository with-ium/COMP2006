#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scheduler.h"
#include "simulator.h"

#define INPUT_SIZE 10
#define ON 1
#define OFF 0

int main(void) {
    FILE *fp;
    /*  
        cylinders = Total cylinders of disk 
        cur = Current position of head
        prev = Previous disk request
        size = Actual size of request array
        menu = Control flag for quitting
        input = Input string
    */
    int cylinders = 0, cur = 0, prev = 0, size = 0;
    int menu = ON;
    int *requests = NULL;
    char input[INPUT_SIZE];

    while (menu != OFF) {
        /* User prompt */
        printf("\nDisk Scheduler Simulation:\n");
        scanf("%s", input);
        /* File handling */
        if (strcmp(input, "QUIT") != 0) {
            fp = fopen(input, "r");
            if (fp == NULL) {
                printf("Error opening argument file.\n");
                exit(1);
            }

            /* Component assignments */
            fscanf(fp, "%d", &cylinders); requests = (int*)malloc(cylinders * sizeof(int));
            fscanf(fp, "%d", &cur);
            fscanf(fp, "%d", &prev);
            while (fscanf(fp, "%d", &requests[size]) == 1) {
                size += 1;
            }
            requests = (int*)realloc(requests, size * sizeof(int));     /* Retrieve number of requests and reallocate array to fit them. */
            
            /* Seek time output */
            printf("\nFor %s:\n", input);
            
        } else {
            menu = OFF;
        }
        createThreads(input, cur, prev, requests, size, cylinders); 
        size = 0;   /* Reset size of requests for next iteration */

        free(requests);
        requests = NULL;

        fclose(fp);
    }
    printf("\nQuitting simulation.");

    return 0;
}
