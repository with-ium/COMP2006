#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int scheduler_compare(const void * num1, const void * num2) {
    if (*(int*)num1 > *(int*)num2) {
        return 1;
    }
    return -1;
}

/* First Come First Serve */
int FCFS(int curPos, int* requests, int size) {
    int seek_time = 0, head = curPos, next = 0;

    int i;
    for (i = 0; i < size; i++) {
        next = requests[i];
        seek_time += abs(next-head);
        head = next;
    }

    return seek_time;
}

/* Shortest Seek Time First */
int SSTF(int curPos, int* requests, int size) {
    int seek_time = 0, head = curPos, min = INT_MAX, idx = 0; 
    int* requests_copy = (int*)malloc(size * sizeof(int));
    
    int i, j, k;
    for (k = 0; k < size; k++) {
        requests_copy[k] = requests[k];
    }

    for (i = 0; i < size; i++) { 
        for (j = 0; j < size; j++) {
            if (head != requests_copy[j] && abs(head-requests_copy[j]) < min) {
                min = abs(head-requests_copy[j]);
                idx = j;
            }
        }
        head = requests_copy[idx];
        seek_time += min;

        min = INT_MAX;
        requests_copy[idx] = INT_MAX;
    }

    free(requests_copy);
    requests_copy = NULL;

    return seek_time;
}

/* SCAN */
int SCAN(int curPos, int prevPos, int* requests, int size, int diskSize) {
    int seek_time = 0, head = curPos, direction = 0;
    int i, steps;

    int* left = (int*)malloc(size * sizeof(int)); 
    int* right = (int*)malloc(size * sizeof(int));
    int leftSize = 0, rightSize = 0;

    /* Check head direction */
    if (head > prevPos) {
        direction = 1; rightSize = 1;   /* right */
        right[0] = diskSize-1;
    }
    else if (head < prevPos) {
        direction = 0; leftSize = 1;    /* left */
        left[0] = 0;
    }

    /* Partition positions into left and right array */
    for (i = 0; i < size; i++) {
        if (head > requests[i]) {
            left[leftSize] = requests[i];
            leftSize += 1;
        }
        else if (head < requests[i]) {
            right[rightSize] = requests[i]; 
            rightSize += 1;
        }
    }

    /* Reallocate arrays and sort them */
    left = (int*)realloc(left, leftSize * sizeof(int)); qsort(left, leftSize, sizeof(int), scheduler_compare);
    right = (int*)realloc(right, rightSize * sizeof(int)); qsort(right, rightSize, sizeof(int), scheduler_compare);

    /* Sort and calculate seek time based on disk direction */
    for (steps = 0; steps < 2; steps++) {
        if (direction == 0) {
            int l;
            for (l = leftSize-1; l >= 0; l--) {
                seek_time += abs(left[l] - head);
                head = left[l];
            }
            direction = 1;
        }
        else if (direction == 1) {
            int r;
            for (r = 0; r < rightSize; r++) {
                seek_time += abs(right[r] - head);
                head = right[r];
            }
            direction = 0;
        }
    }

    free(left); free(right);
    left = NULL; right = NULL;

    return seek_time;
}

/* C-SCAN */
int C_SCAN(int curPos, int prevPos, int* requests, int size, int diskSize) {
    int seek_time = 0, head = curPos, direction = 0;
    int i, steps;

    int* left = (int*)malloc(size * sizeof(int)); 
    int* right = (int*)malloc(size * sizeof(int));

    /* leftSize and rightSize are 1 to include end values of disk */
    int leftSize = 1, rightSize = 1;
    left[0] = 0;
    right[0] = diskSize-1;

    /* Check head direction */
    if (head > prevPos) {
        direction = 1;  /* right */
    }
    else if (head < prevPos) {
        direction = 0;  /* left */
    }

    /* Partition positions into left and right array */
    for (i = 0; i < size; i++) {
        if (requests[i] != left[0] && requests[i] != right[0]) {
            if (head > requests[i]) {
                left[leftSize] = requests[i];
                leftSize += 1;
            }
            else if (head < requests[i]) {
                right[rightSize] = requests[i]; 
                rightSize += 1;
            }
        }
    }

    /* Reallocate arrays and sort them */
    left = (int*)realloc(left, leftSize * sizeof(int)); qsort(left, leftSize, sizeof(int), scheduler_compare);
    right = (int*)realloc(right, rightSize * sizeof(int)); qsort(right, rightSize, sizeof(int), scheduler_compare);

    /* Sort and calculate seek time based on disk direction */
    for (steps = 0; steps < 2; steps++) {
        if (direction == 0) {
            int l;
            for (l = 0; l < leftSize; l++) {
                seek_time += abs(left[l] - head);
                head = left[l];
            }
            direction = 1;
        }
        else if (direction == 1) {
            int r;
            for (r = rightSize-1; r >= 0; r--) {
                seek_time += abs(right[r] - head);
                head = right[r]; 
            }
            direction = 0;
        }
    }

    free(left); free(right);
    left = NULL; right = NULL;

    return seek_time;
}

/* LOOK */
int LOOK(int curPos, int prevPos, int* requests, int size) {
    int seek_time = 0, head = curPos, direction = 0;
    int i, steps;

    int* left = (int*)malloc(size * sizeof(int)); 
    int* right = (int*)malloc(size * sizeof(int));
    int leftSize = 0, rightSize = 0;

    /* Check head direction */
    if (head > prevPos) {
        direction = 1;  /* right */
    }
    else if (head < prevPos) {
        direction = 0;  /* left */
    }

    /* Partition positions into left and right array */
    for (i = 0; i < size; i++) {
        if (head > requests[i]) {
            left[leftSize] = requests[i];
            leftSize += 1;
        }
        else if (head < requests[i]) {
            right[rightSize] = requests[i]; 
            rightSize += 1;
        }
    }

    /* Reallocate arrays and sort them */
    left = (int*)realloc(left, leftSize * sizeof(int)); qsort(left, leftSize, sizeof(int), scheduler_compare);
    right = (int*)realloc(right, rightSize * sizeof(int)); qsort(right, rightSize, sizeof(int), scheduler_compare);

    /* Sort and calculate seek time based on disk direction */
    for (steps = 0; steps < 2; steps++) {
        if (direction == 0) {
            int l;
            for (l = leftSize-1; l >= 0; l--) {
                seek_time += abs(left[l] - head);
                head = left[l];
            }
            direction = 1;
        }
        else if (direction == 1) {
            int r;
            for (r = 0; r < rightSize; r++) {
                seek_time += abs(right[r] - head);
                head = right[r]; 
            }
            direction = 0;
        }
    }

    free(left); free(right);
    left = NULL; right = NULL;

    return seek_time;
}

/* C-LOOK */
int C_LOOK(int curPos, int prevPos, int* requests, int size) {
    int seek_time = 0, head = curPos, direction = 0;
    int i, steps;

    int* left = (int*)malloc(size * sizeof(int)); 
    int* right = (int*)malloc(size * sizeof(int));
    int leftSize = 0, rightSize = 0;

    /* Check head direction */
    if (head > prevPos) {
        direction = 1;  /* right */
    }
    else if (head < prevPos) {
        direction = 0;  /* left */
    }

    /* Partition positions into left and right array */
    for (i = 0; i < size; i++) {
        if (head > requests[i]) {
            left[leftSize] = requests[i];
            leftSize += 1;
        }
        else if (head < requests[i]) {
            right[rightSize] = requests[i]; 
            rightSize += 1;
        }
    }

    /* Reallocate arrays and sort them */
    left = (int*)realloc(left, leftSize * sizeof(int)); qsort(left, leftSize, sizeof(int), scheduler_compare);
    right = (int*)realloc(right, rightSize * sizeof(int)); qsort(right, rightSize, sizeof(int), scheduler_compare);

    /* Sort and calculate seek time based on disk direction */
    for (steps = 0; steps < 2; steps++) {
        if (direction == 0) {
            int l;
            for (l = 0; l < leftSize; l++) {
                seek_time += abs(left[l] - head);
                head = left[l];
            }
            direction = 1;
        }
        else if (direction == 1) {
            int r;
            for (r = rightSize-1; r >= 0; r--) {
                seek_time += abs(right[r] - head);
                head = right[r]; 
            }
            direction = 0;
        }
    }

    free(left); free(right);
    left = NULL; right = NULL;

    return seek_time;
}
